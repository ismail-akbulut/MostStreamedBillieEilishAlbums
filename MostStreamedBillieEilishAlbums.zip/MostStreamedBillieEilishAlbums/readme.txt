TURKISH - TR
- - - - - - - - - - - -
Bu veri bilimi öğrenme yolundaki ilk github projem. Hayranı Olduğum dünyaca ünlü yıldız Billie Eilish'in en çok dinlenen albümlerinin grafiğini oluşturan python programını yazdım.

Albüm dinlenme verilerini bir Excel dosyasından okur
- Veriyi Pandas ile temizler ve işler
- Albümlerin toplam dinlenme sayılarını bar chart ile görselleştirir

  Kullanılan Teknolojiler:
- Python
- Pandas
- Matplotlib


ENGLISH - EN
- - - - - - - - - - - 
That's my first github Project on journey of learning data science. Singer called Billie Eilish who i admire to her, In this project, I analyzed the most streamed albums of her

-Reads album stream data from an Excel file

-Cleans and processes the data using Pandas

-Show the most streamed albums with a bar chart

Technologies I Used
- Python
- Pandas
- Matplotlib